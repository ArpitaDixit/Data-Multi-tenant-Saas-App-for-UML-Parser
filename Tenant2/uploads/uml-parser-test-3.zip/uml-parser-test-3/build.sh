javac *.java
